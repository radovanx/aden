var assert = require('assert');

describe('align-content', function() {

  /**
   * If you want to test this code, comment 'alignContent.result' from align-content.js
   */
  // it('should return start', function (done) {
  //   test.alignContent.ms('flex-start', 'start', done);
  // });

});
